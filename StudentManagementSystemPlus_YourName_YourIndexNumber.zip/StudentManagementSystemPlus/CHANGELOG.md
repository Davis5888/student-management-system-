# Changelog

All notable changes to Student Management System Plus are documented here.

## [1.0.0] - 2026-02-23

### Added
- Initial release of Student Management System Plus
- Dashboard screen with live statistics (total, active, inactive students, average GPA)
- Students screen with full CRUD operations (Add, Edit, Delete)
- TableView with all student fields
- Search by student ID or full name
- Filter by programme, level, and status
- Sort by GPA (descending) and full name (ascending)
- Reports screen with four report types:
  - Top Performers (configurable N, filterable by programme and level)
  - At-Risk Students (configurable GPA threshold)
  - GPA Distribution (banded counts)
  - Programme Summary (total and average GPA per programme)
- CSV export for: all students, top performers, at-risk students
- CSV import with row-level validation and error reporting
- Import error report saved to `data/` folder
- Settings screen for at-risk GPA threshold and programme management
- SQLite database with constraints (NOT NULL, CHECK on level and GPA, PRIMARY KEY)
- Prepared statements for all SQL operations
- Layered architecture: domain, service, repository, ui, util
- Validation in both UI and service layers
- Background thread processing for import/export to prevent UI freezing
- File-based logging to `data/app.log`
- 26 unit tests covering validation, report calculations, and service logic
- CSS stylesheet with professional look and feel

### Technical
- Java 17+, JavaFX 21, SQLite JDBC 3.45, Maven build
- `mvn test` runs all unit tests
