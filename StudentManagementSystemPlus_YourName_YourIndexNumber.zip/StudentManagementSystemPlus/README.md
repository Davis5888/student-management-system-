# Student Management System Plus

**Version:** 1.0.0  
**Platform:** Windows (Offline First)  
**Technology Stack:** Java 17+, JavaFX 21, SQLite (JDBC), Maven

---

## Overview

Student Management System Plus is a desktop application for managing student records in an academic department. It supports full CRUD operations, search, filter, sorting, reports, CSV import/export, and data validation — all running fully offline.

---

## Features

- **Dashboard** – Live stats (total, active, inactive, avg GPA) with quick navigation
- **Students Screen** – Add, edit, delete, search, filter by programme/level/status, sort by GPA/name
- **Reports** – Top performers, at-risk students, GPA distribution, programme summary
- **Import/Export** – CSV import with error reporting, CSV export for all students and reports
- **Settings** – Configure at-risk GPA threshold, manage programme list
- **Validation** – Input validated in both UI and service layers
- **Logging** – Persistent log file in `data/app.log`

---

## How to Run on Windows

### Prerequisites

1. **Java 17 or later** – Download from [https://adoptium.net](https://adoptium.net)
2. **JavaFX SDK 21** – Download from [https://gluonhq.com/products/javafx/](https://gluonhq.com/products/javafx/)
   - Extract to e.g. `C:\javafx\javafx-sdk-21`
3. **Maven 3.8+** (optional, for building and testing)

### Option A: Run from compiled JAR

```cmd
java --module-path "C:\javafx\javafx-sdk-21\lib" ^
     --add-modules javafx.controls,javafx.fxml ^
     -jar StudentManagementSystemPlus.jar
```

See `RUN_VM_OPTIONS.txt` for exact VM options.

### Option B: Run with Maven

```cmd
mvn javafx:run
```

### Option C: Build and run

```cmd
mvn clean package
java --module-path "C:\javafx\javafx-sdk-21\lib" ^
     --add-modules javafx.controls,javafx.fxml ^
     -jar target\StudentManagementSystemPlus.jar
```

---

## Running Tests

```cmd
mvn test
```

Test results are saved to `target/surefire-reports/`. A captured copy is in `evidence/test_output.txt`.

---

## Project Structure

```
StudentManagementSystemPlus/
├── pom.xml
├── README.md
├── RUN_VM_OPTIONS.txt
├── CHANGELOG.md
├── data/                          # Database, logs, exports (auto-created)
├── evidence/                      # Test output evidence
├── src/
│   ├── main/
│   │   ├── java/com/sms/
│   │   │   ├── MainApp.java
│   │   │   ├── domain/            # Student, ValidationResult, AppSettings, ImportResult
│   │   │   ├── service/           # StudentService, ValidationService, ReportService, ImportExportService
│   │   │   ├── repository/        # StudentRepository interface + SQLiteStudentRepository
│   │   │   └── ui/controllers/    # JavaFX controllers (Main, Dashboard, Students, Reports, etc.)
│   │   └── resources/com/sms/ui/  # FXML files + CSS
│   └── test/
│       └── java/com/sms/service/  # Unit tests (ValidationServiceTest, ReportServiceTest, StudentServiceTest)
```

---

## CSV Import Format

The import CSV must have this header row:

```
StudentID,FullName,Programme,Level,GPA,Email,PhoneNumber,DateAdded,Status
```

Example row:
```
STU001,"John Doe","Computer Science",200,3.5,"john@example.com","0200001234","2025-01-15","Active"
```

Invalid rows are skipped and logged to `data/import_errors_<timestamp>.csv`.

---

## Data Storage

- Database: `data/students.db` (SQLite)
- Logs: `data/app.log`
- Exports: `data/students_export_*.csv`, `data/top_performers_*.csv`, `data/at_risk_*.csv`
- Import errors: `data/import_errors_*.csv`

---

## Academic Integrity

This project was developed individually. AI tools (Claude) were used for code scaffolding, reviewed and understood by the student before submission.
