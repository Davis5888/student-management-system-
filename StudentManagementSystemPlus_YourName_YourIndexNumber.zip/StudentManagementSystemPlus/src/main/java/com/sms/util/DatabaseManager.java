package com.sms.util;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Manages SQLite database connection and schema creation.
 */
public class DatabaseManager {

    private static final String DB_DIR = "data";
    private static final String DB_FILE = "students.db";
    private static final String DB_URL = "jdbc:sqlite:" + DB_DIR + File.separator + DB_FILE;

    private static Connection connection;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            File dir = new File(DB_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            connection = DriverManager.getConnection(DB_URL);
            connection.setAutoCommit(true);
        }
        return connection;
    }

    public static void initializeDatabase() throws SQLException {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS students (
                    student_id   TEXT PRIMARY KEY NOT NULL,
                    full_name    TEXT NOT NULL,
                    programme    TEXT NOT NULL,
                    level        INTEGER NOT NULL CHECK(level IN (100,200,300,400,500,600,700)),
                    gpa          REAL NOT NULL CHECK(gpa >= 0.0 AND gpa <= 4.0),
                    email        TEXT NOT NULL,
                    phone_number TEXT NOT NULL,
                    date_added   TEXT NOT NULL,
                    status       TEXT NOT NULL DEFAULT 'Active'
                )
            """);

            AppLogger.info("Database initialized successfully.");
        }
    }

    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException e) {
                AppLogger.error("Error closing database connection: " + e.getMessage());
            }
        }
    }
}
