package com.sms.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Simple file-based logger. Does not log personal record details.
 */
public class AppLogger {

    private static final String LOG_DIR = "data";
    private static final String LOG_FILE = LOG_DIR + File.separator + "app.log";
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void info(String message) {
        log("INFO", message);
    }

    public static void error(String message) {
        log("ERROR", message);
    }

    public static void warn(String message) {
        log("WARN", message);
    }

    private static void log(String level, String message) {
        File dir = new File(LOG_DIR);
        if (!dir.exists()) dir.mkdirs();

        String entry = "[" + LocalDateTime.now().format(FORMATTER) + "] [" + level + "] " + message;
        System.out.println(entry);

        try (PrintWriter pw = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            pw.println(entry);
        } catch (IOException e) {
            System.err.println("Logger error: " + e.getMessage());
        }
    }
}
