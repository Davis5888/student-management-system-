package com.sms.util;

import com.sms.repository.SQLiteStudentRepository;
import com.sms.repository.StudentRepository;
import com.sms.service.ImportExportService;
import com.sms.service.ReportService;
import com.sms.service.StudentService;
import com.sms.service.ValidationService;

/**
 * Simple service locator / dependency container.
 */
public class ServiceLocator {

    private static ServiceLocator instance;

    private final StudentRepository studentRepository;
    private final ValidationService validationService;
    private final StudentService studentService;
    private final ReportService reportService;
    private final ImportExportService importExportService;
    private final ProgrammeRegistry programmeRegistry;

    private ServiceLocator() {
        studentRepository   = new SQLiteStudentRepository();
        validationService   = new ValidationService();
        studentService      = new StudentService(studentRepository, validationService);
        reportService       = new ReportService(studentRepository);
        importExportService = new ImportExportService(studentRepository, validationService);
        programmeRegistry   = new ProgrammeRegistry();
    }

    public static ServiceLocator getInstance() {
        if (instance == null) {
            instance = new ServiceLocator();
        }
        return instance;
    }

    public StudentService getStudentService()         { return studentService; }
    public ReportService getReportService()           { return reportService; }
    public ImportExportService getImportExportService() { return importExportService; }
    public ProgrammeRegistry getProgrammeRegistry()   { return programmeRegistry; }
}
