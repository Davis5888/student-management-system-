package com.sms.util;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Registry for available programmes.
 */
public class ProgrammeRegistry {

    private final ObservableList<String> programmes = FXCollections.observableArrayList(
            "Computer Science",
            "Information Technology",
            "Software Engineering",
            "Electrical Engineering",
            "Mathematics",
            "Business Administration",
            "Accounting",
            "Economics"
    );

    public ObservableList<String> getProgrammes() {
        return programmes;
    }

    public void addProgramme(String name) {
        if (!name.isBlank() && !programmes.contains(name)) {
            programmes.add(name);
            programmes.sort(String::compareToIgnoreCase);
        }
    }

    public void removeProgramme(String name) {
        programmes.remove(name);
    }
}
