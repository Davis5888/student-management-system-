package com.sms.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Holds the result of a validation operation.
 */
public class ValidationResult {

    private final List<String> errors = new ArrayList<>();

    public void addError(String message) {
        errors.add(message);
    }

    public boolean isValid() {
        return errors.isEmpty();
    }

    public List<String> getErrors() {
        return errors;
    }

    public String getErrorMessage() {
        return String.join("\n", errors);
    }
}
