package com.sms.domain;

/**
 * Application-wide settings.
 */
public class AppSettings {

    private double atRiskGpaThreshold = 2.0;

    private static AppSettings instance;

    private AppSettings() {}

    public static AppSettings getInstance() {
        if (instance == null) {
            instance = new AppSettings();
        }
        return instance;
    }

    public double getAtRiskGpaThreshold() {
        return atRiskGpaThreshold;
    }

    public void setAtRiskGpaThreshold(double atRiskGpaThreshold) {
        this.atRiskGpaThreshold = atRiskGpaThreshold;
    }
}
