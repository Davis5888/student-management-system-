package com.sms.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Result of a CSV import operation.
 */
public class ImportResult {

    private int successCount = 0;
    private int errorCount = 0;
    private final List<String> errorMessages = new ArrayList<>();

    public void addSuccess() { successCount++; }
    public void addError(int row, String message) {
        errorCount++;
        errorMessages.add("Row " + row + ": " + message);
    }

    public int getSuccessCount() { return successCount; }
    public int getErrorCount() { return errorCount; }
    public List<String> getErrorMessages() { return errorMessages; }
}
