package com.sms.repository;

import com.sms.domain.Student;
import com.sms.util.AppLogger;
import com.sms.util.DatabaseManager;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * SQLite implementation of StudentRepository.
 * Uses prepared statements for all queries.
 */
public class SQLiteStudentRepository implements StudentRepository {

    @Override
    public void add(Student student) {
        String sql = "INSERT INTO students (student_id, full_name, programme, level, gpa, email, phone_number, date_added, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            setStudentParams(ps, student);
            ps.setString(9, student.getStatus());
            ps.executeUpdate();
            AppLogger.info("Student added: ID=" + student.getStudentId());
        } catch (SQLException e) {
            AppLogger.error("DB error adding student: " + e.getMessage());
            throw new RuntimeException("Failed to add student: " + e.getMessage(), e);
        }
    }

    @Override
    public void update(Student student) {
        String sql = "UPDATE students SET full_name=?, programme=?, level=?, gpa=?, email=?, phone_number=?, date_added=?, status=? " +
                     "WHERE student_id=?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, student.getFullName());
            ps.setString(2, student.getProgramme());
            ps.setInt(3, student.getLevel());
            ps.setDouble(4, student.getGpa());
            ps.setString(5, student.getEmail());
            ps.setString(6, student.getPhoneNumber());
            ps.setString(7, student.getDateAdded().toString());
            ps.setString(8, student.getStatus());
            ps.setString(9, student.getStudentId());
            ps.executeUpdate();
            AppLogger.info("Student updated: ID=" + student.getStudentId());
        } catch (SQLException e) {
            AppLogger.error("DB error updating student: " + e.getMessage());
            throw new RuntimeException("Failed to update student: " + e.getMessage(), e);
        }
    }

    @Override
    public void delete(String studentId) {
        String sql = "DELETE FROM students WHERE student_id=?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, studentId);
            ps.executeUpdate();
            AppLogger.info("Student deleted: ID=" + studentId);
        } catch (SQLException e) {
            AppLogger.error("DB error deleting student: " + e.getMessage());
            throw new RuntimeException("Failed to delete student: " + e.getMessage(), e);
        }
    }

    @Override
    public Optional<Student> findById(String studentId) {
        String sql = "SELECT * FROM students WHERE student_id=?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, studentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return Optional.of(mapRow(rs));
            }
        } catch (SQLException e) {
            AppLogger.error("DB error finding student by ID: " + e.getMessage());
        }
        return Optional.empty();
    }

    @Override
    public List<Student> findAll() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students ORDER BY full_name ASC";
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                students.add(mapRow(rs));
            }
        } catch (SQLException e) {
            AppLogger.error("DB error finding all students: " + e.getMessage());
        }
        return students;
    }

    @Override
    public List<Student> findByName(String name) {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students WHERE LOWER(full_name) LIKE ? OR student_id LIKE ? ORDER BY full_name ASC";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String pattern = "%" + name.toLowerCase() + "%";
            ps.setString(1, pattern);
            ps.setString(2, pattern);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                students.add(mapRow(rs));
            }
        } catch (SQLException e) {
            AppLogger.error("DB error searching students: " + e.getMessage());
        }
        return students;
    }

    @Override
    public List<Student> findByFilters(String programme, Integer level, String status) {
        List<Student> students = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM students WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (programme != null && !programme.isEmpty() && !programme.equals("All")) {
            sql.append(" AND programme=?");
            params.add(programme);
        }
        if (level != null) {
            sql.append(" AND level=?");
            params.add(level);
        }
        if (status != null && !status.isEmpty() && !status.equals("All")) {
            sql.append(" AND status=?");
            params.add(status);
        }
        sql.append(" ORDER BY full_name ASC");

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                students.add(mapRow(rs));
            }
        } catch (SQLException e) {
            AppLogger.error("DB error filtering students: " + e.getMessage());
        }
        return students;
    }

    @Override
    public boolean existsById(String studentId) {
        String sql = "SELECT COUNT(*) FROM students WHERE student_id=?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, studentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            AppLogger.error("DB error checking existence: " + e.getMessage());
        }
        return false;
    }

    @Override
    public int count() {
        String sql = "SELECT COUNT(*) FROM students";
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            AppLogger.error("DB error counting students: " + e.getMessage());
        }
        return 0;
    }

    @Override
    public int countByStatus(String status) {
        String sql = "SELECT COUNT(*) FROM students WHERE status=?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            AppLogger.error("DB error counting by status: " + e.getMessage());
        }
        return 0;
    }

    @Override
    public double averageGpa() {
        String sql = "SELECT AVG(gpa) FROM students";
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            AppLogger.error("DB error computing average GPA: " + e.getMessage());
        }
        return 0.0;
    }

    private void setStudentParams(PreparedStatement ps, Student student) throws SQLException {
        ps.setString(1, student.getStudentId());
        ps.setString(2, student.getFullName());
        ps.setString(3, student.getProgramme());
        ps.setInt(4, student.getLevel());
        ps.setDouble(5, student.getGpa());
        ps.setString(6, student.getEmail());
        ps.setString(7, student.getPhoneNumber());
        ps.setString(8, student.getDateAdded().toString());
    }

    private Student mapRow(ResultSet rs) throws SQLException {
        return new Student(
            rs.getString("student_id"),
            rs.getString("full_name"),
            rs.getString("programme"),
            rs.getInt("level"),
            rs.getDouble("gpa"),
            rs.getString("email"),
            rs.getString("phone_number"),
            LocalDate.parse(rs.getString("date_added")),
            rs.getString("status")
        );
    }
}
