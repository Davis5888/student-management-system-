package com.sms.repository;

import com.sms.domain.Student;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Student data access.
 */
public interface StudentRepository {

    void add(Student student);

    void update(Student student);

    void delete(String studentId);

    Optional<Student> findById(String studentId);

    List<Student> findAll();

    List<Student> findByName(String name);

    List<Student> findByFilters(String programme, Integer level, String status);

    boolean existsById(String studentId);

    int count();

    int countByStatus(String status);

    double averageGpa();
}
