package com.sms.ui.controllers;

import com.sms.domain.ImportResult;
import com.sms.service.ImportExportService;
import com.sms.service.ReportService;
import com.sms.service.StudentService;
import com.sms.util.ServiceLocator;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;

/**
 * Import/Export screen controller. Uses background threads for long operations.
 */
public class ImportExportController {

    @FXML private TextField txtImportFile;
    @FXML private VBox importResultBox;
    @FXML private Label lblImportSuccess;
    @FXML private Label lblImportErrors;
    @FXML private ListView<String> lstErrors;
    @FXML private Label lblExportStatus;

    private final ImportExportService ioService = ServiceLocator.getInstance().getImportExportService();
    private final StudentService studentService = ServiceLocator.getInstance().getStudentService();
    private final ReportService reportService = ServiceLocator.getInstance().getReportService();

    @FXML public void browseImport() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Select CSV File");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = chooser.showOpenDialog(txtImportFile.getScene().getWindow());
        if (file != null) txtImportFile.setText(file.getAbsolutePath());
    }

    @FXML public void importCsv() {
        String path = txtImportFile.getText().trim();
        if (path.isEmpty()) {
            lblExportStatus.setText("Please select a CSV file first.");
            return;
        }
        lblExportStatus.setText("Importing...");

        // Run in background thread
        new Thread(() -> {
            try {
                ImportResult result = ioService.importFromCsv(path);
                Platform.runLater(() -> showImportResult(result));
            } catch (IOException e) {
                Platform.runLater(() -> lblExportStatus.setText("Import failed: " + e.getMessage()));
            }
        }).start();
    }

    private void showImportResult(ImportResult result) {
        importResultBox.setVisible(true);
        lblImportSuccess.setText("Successfully imported: " + result.getSuccessCount() + " records");
        lblImportErrors.setText("Errors: " + result.getErrorCount());
        lstErrors.setItems(FXCollections.observableArrayList(result.getErrorMessages()));
        lblExportStatus.setText("Import complete.");
    }

    @FXML public void exportAll() {
        new Thread(() -> {
            try {
                String file = ioService.exportAllStudents();
                Platform.runLater(() -> lblExportStatus.setText("Exported all students to: " + file));
            } catch (IOException e) {
                Platform.runLater(() -> lblExportStatus.setText("Export failed: " + e.getMessage()));
            }
        }).start();
    }

    @FXML public void exportTop() {
        new Thread(() -> {
            try {
                String file = ioService.exportTopPerformers(reportService.getTopPerformers(10, null, null));
                Platform.runLater(() -> lblExportStatus.setText("Top performers exported to: " + file));
            } catch (IOException e) {
                Platform.runLater(() -> lblExportStatus.setText("Export failed: " + e.getMessage()));
            }
        }).start();
    }

    @FXML public void exportAtRisk() {
        new Thread(() -> {
            try {
                double threshold = com.sms.domain.AppSettings.getInstance().getAtRiskGpaThreshold();
                String file = ioService.exportAtRisk(reportService.getAtRiskStudents(threshold));
                Platform.runLater(() -> lblExportStatus.setText("At-risk exported to: " + file));
            } catch (IOException e) {
                Platform.runLater(() -> lblExportStatus.setText("Export failed: " + e.getMessage()));
            }
        }).start();
    }
}
