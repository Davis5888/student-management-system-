package com.sms.ui.controllers;

import com.sms.service.StudentService;
import com.sms.util.ServiceLocator;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * Dashboard screen controller.
 */
public class DashboardController implements NavigatorAware {

    @FXML private Label lblTotal;
    @FXML private Label lblActive;
    @FXML private Label lblInactive;
    @FXML private Label lblAvgGpa;

    private final StudentService studentService = ServiceLocator.getInstance().getStudentService();
    private MainController navigator;

    @FXML
    public void initialize() {
        refresh();
    }

    @FXML
    public void refresh() {
        lblTotal.setText(String.valueOf(studentService.getTotalCount()));
        lblActive.setText(String.valueOf(studentService.getActiveCount()));
        lblInactive.setText(String.valueOf(studentService.getInactiveCount()));
        lblAvgGpa.setText(String.format("%.2f", studentService.getAverageGpa()));
    }

    @FXML public void goStudents()      { if (navigator != null) navigator.showStudents(); }
    @FXML public void goReports()       { if (navigator != null) navigator.showReports(); }
    @FXML public void goImportExport()  { if (navigator != null) navigator.showImportExport(); }
    @FXML public void goSettings()      { if (navigator != null) navigator.showSettings(); }

    @Override
    public void setNavigator(MainController navigator) {
        this.navigator = navigator;
    }
}
