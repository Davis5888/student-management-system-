package com.sms.ui.controllers;

/**
 * Controllers that need to trigger navigation implement this.
 */
public interface NavigatorAware {
    void setNavigator(MainController navigator);
}
