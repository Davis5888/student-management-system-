package com.sms.ui.controllers;

import com.sms.domain.AppSettings;
import com.sms.domain.Student;
import com.sms.service.ImportExportService;
import com.sms.service.ReportService;
import com.sms.util.ProgrammeRegistry;
import com.sms.util.ServiceLocator;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Reports screen controller.
 */
public class ReportsController {

    // Top Performers
    @FXML private ComboBox<String> cboTopProg;
    @FXML private ComboBox<String> cboTopLevel;
    @FXML private TextField txtTopN;
    @FXML private TableView<Student> tblTop;
    @FXML private TableColumn<Student, Integer> colTopRank;
    @FXML private TableColumn<Student, String>  colTopId;
    @FXML private TableColumn<Student, String>  colTopName;
    @FXML private TableColumn<Student, String>  colTopProg;
    @FXML private TableColumn<Student, Integer> colTopLevel;
    @FXML private TableColumn<Student, Double>  colTopGpa;

    // At Risk
    @FXML private TextField txtThreshold;
    @FXML private TableView<Student> tblAtRisk;
    @FXML private TableColumn<Student, String>  colArId;
    @FXML private TableColumn<Student, String>  colArName;
    @FXML private TableColumn<Student, String>  colArProg;
    @FXML private TableColumn<Student, Integer> colArLevel;
    @FXML private TableColumn<Student, Double>  colArGpa;
    @FXML private TableColumn<Student, String>  colArStatus;

    // GPA Distribution
    @FXML private TableView<Map.Entry<String, Long>> tblDist;
    @FXML private TableColumn<Map.Entry<String, Long>, String> colDistBand;
    @FXML private TableColumn<Map.Entry<String, Long>, Long>   colDistCount;

    // Programme Summary
    @FXML private TableView<Map<String, Object>> tblSummary;
    @FXML private TableColumn<Map<String, Object>, String> colSumProg;
    @FXML private TableColumn<Map<String, Object>, String> colSumTotal;
    @FXML private TableColumn<Map<String, Object>, String> colSumAvg;

    @FXML private Label lblReportStatus;

    private final ReportService reportService = ServiceLocator.getInstance().getReportService();
    private final ImportExportService ioService = ServiceLocator.getInstance().getImportExportService();
    private final ProgrammeRegistry programmeRegistry = ServiceLocator.getInstance().getProgrammeRegistry();

    private List<Student> lastTopList;
    private List<Student> lastAtRiskList;

    @FXML
    public void initialize() {
        setupTopTable();
        setupAtRiskTable();
        setupDistTable();
        setupSummaryTable();

        ObservableList<String> progs = FXCollections.observableArrayList("All");
        progs.addAll(programmeRegistry.getProgrammes());
        cboTopProg.setItems(progs);
        cboTopProg.setValue("All");

        cboTopLevel.setItems(FXCollections.observableArrayList("All", "100", "200", "300", "400", "500", "600", "700"));
        cboTopLevel.setValue("All");

        txtThreshold.setText(String.valueOf(AppSettings.getInstance().getAtRiskGpaThreshold()));
    }

    private void setupTopTable() {
        AtomicInteger[] counter = {new AtomicInteger(0)};
        colTopRank.setCellValueFactory(c -> {
            List<Student> items = tblTop.getItems();
            return new ReadOnlyObjectWrapper<>(items.indexOf(c.getValue()) + 1);
        });
        colTopId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colTopName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colTopProg.setCellValueFactory(new PropertyValueFactory<>("programme"));
        colTopLevel.setCellValueFactory(new PropertyValueFactory<>("level"));
        colTopGpa.setCellValueFactory(new PropertyValueFactory<>("gpa"));
    }

    private void setupAtRiskTable() {
        colArId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colArName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colArProg.setCellValueFactory(new PropertyValueFactory<>("programme"));
        colArLevel.setCellValueFactory(new PropertyValueFactory<>("level"));
        colArGpa.setCellValueFactory(new PropertyValueFactory<>("gpa"));
        colArStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void setupDistTable() {
        colDistBand.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getKey()));
        colDistCount.setCellValueFactory(c -> new ReadOnlyObjectWrapper<>(c.getValue().getValue()));
    }

    private void setupSummaryTable() {
        colSumProg.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().get("Programme").toString()));
        colSumTotal.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().get("Total").toString()));
        colSumAvg.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().get("Average GPA").toString()));
    }

    @FXML public void genTopPerformers() {
        int n = 10;
        try { n = Integer.parseInt(txtTopN.getText().trim()); } catch (NumberFormatException ignore) {}
        String prog = cboTopProg.getValue();
        String levelStr = cboTopLevel.getValue();
        Integer level = (levelStr == null || levelStr.equals("All")) ? null : Integer.parseInt(levelStr);
        lastTopList = reportService.getTopPerformers(n, prog, level);
        tblTop.setItems(FXCollections.observableArrayList(lastTopList));
        lblReportStatus.setText("Top " + lastTopList.size() + " performers loaded.");
    }

    @FXML public void exportTopPerformers() {
        if (lastTopList == null || lastTopList.isEmpty()) { genTopPerformers(); }
        try {
            String file = ioService.exportTopPerformers(lastTopList);
            lblReportStatus.setText("Exported to: " + file);
        } catch (IOException e) {
            lblReportStatus.setText("Export failed: " + e.getMessage());
        }
    }

    @FXML public void genAtRisk() {
        double threshold;
        try { threshold = Double.parseDouble(txtThreshold.getText().trim()); }
        catch (NumberFormatException e) { threshold = AppSettings.getInstance().getAtRiskGpaThreshold(); }
        lastAtRiskList = reportService.getAtRiskStudents(threshold);
        tblAtRisk.setItems(FXCollections.observableArrayList(lastAtRiskList));
        lblReportStatus.setText(lastAtRiskList.size() + " at-risk students found.");
    }

    @FXML public void exportAtRisk() {
        if (lastAtRiskList == null || lastAtRiskList.isEmpty()) { genAtRisk(); }
        try {
            String file = ioService.exportAtRisk(lastAtRiskList);
            lblReportStatus.setText("Exported to: " + file);
        } catch (IOException e) {
            lblReportStatus.setText("Export failed: " + e.getMessage());
        }
    }

    @FXML public void genDistribution() {
        Map<String, Long> dist = reportService.getGpaDistribution();
        tblDist.setItems(FXCollections.observableArrayList(dist.entrySet()));
        lblReportStatus.setText("GPA distribution loaded.");
    }

    @FXML public void genProgrammeSummary() {
        List<Map<String, Object>> summary = reportService.getProgrammeSummary();
        tblSummary.setItems(FXCollections.observableArrayList(summary));
        lblReportStatus.setText(summary.size() + " programmes summarized.");
    }
}
