package com.sms.ui.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;

import java.io.IOException;

/**
 * Main shell controller. Handles navigation between screens.
 */
public class MainController {

    @FXML private StackPane contentArea;
    @FXML private Button btnDashboard;
    @FXML private Button btnStudents;
    @FXML private Button btnReports;
    @FXML private Button btnImportExport;
    @FXML private Button btnSettings;

    private Node dashboardView;
    private Node studentsView;
    private Node reportsView;
    private Node importExportView;
    private Node settingsView;

    @FXML
    public void initialize() throws IOException {
        dashboardView    = loadView("/com/sms/ui/DashboardView.fxml");
        studentsView     = loadView("/com/sms/ui/StudentsView.fxml");
        reportsView      = loadView("/com/sms/ui/ReportsView.fxml");
        importExportView = loadView("/com/sms/ui/ImportExportView.fxml");
        settingsView     = loadView("/com/sms/ui/SettingsView.fxml");

        showDashboard();
    }

    @FXML public void showDashboard()     { show(dashboardView);    setActive(btnDashboard); }
    @FXML public void showStudents()      { show(studentsView);     setActive(btnStudents); }
    @FXML public void showReports()       { show(reportsView);      setActive(btnReports); }
    @FXML public void showImportExport()  { show(importExportView); setActive(btnImportExport); }
    @FXML public void showSettings()      { show(settingsView);     setActive(btnSettings); }

    private void show(Node view) {
        contentArea.getChildren().setAll(view);
    }

    private void setActive(Button active) {
        for (Button b : new Button[]{btnDashboard, btnStudents, btnReports, btnImportExport, btnSettings}) {
            b.getStyleClass().remove("nav-btn-active");
        }
        active.getStyleClass().add("nav-btn-active");
    }

    private Node loadView(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
        Node node = loader.load();
        // Inject navigator reference if controller supports it
        Object ctrl = loader.getController();
        if (ctrl instanceof NavigatorAware na) {
            na.setNavigator(this);
        }
        return node;
    }
}
