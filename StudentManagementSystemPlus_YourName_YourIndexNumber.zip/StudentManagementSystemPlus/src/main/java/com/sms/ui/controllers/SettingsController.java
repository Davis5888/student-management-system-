package com.sms.ui.controllers;

import com.sms.domain.AppSettings;
import com.sms.util.ProgrammeRegistry;
import com.sms.util.ServiceLocator;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

/**
 * Settings screen controller.
 */
public class SettingsController {

    @FXML private TextField txtThreshold;
    @FXML private TextField txtNewProgramme;
    @FXML private ListView<String> lstProgrammes;
    @FXML private Label lblSettingsStatus;

    private final ProgrammeRegistry programmeRegistry = ServiceLocator.getInstance().getProgrammeRegistry();

    @FXML
    public void initialize() {
        txtThreshold.setText(String.valueOf(AppSettings.getInstance().getAtRiskGpaThreshold()));
        lstProgrammes.setItems(programmeRegistry.getProgrammes());
    }

    @FXML public void saveThreshold() {
        try {
            double val = Double.parseDouble(txtThreshold.getText().trim());
            if (val < 0 || val > 4.0) throw new NumberFormatException();
            AppSettings.getInstance().setAtRiskGpaThreshold(val);
            lblSettingsStatus.setText("At-risk threshold updated to " + val);
        } catch (NumberFormatException e) {
            lblSettingsStatus.setText("Invalid threshold. Enter a value between 0.0 and 4.0.");
        }
    }

    @FXML public void addProgramme() {
        String name = txtNewProgramme.getText().trim();
        if (name.isEmpty()) { lblSettingsStatus.setText("Programme name cannot be empty."); return; }
        programmeRegistry.addProgramme(name);
        txtNewProgramme.clear();
        lblSettingsStatus.setText("Programme added: " + name);
    }

    @FXML public void removeProgramme() {
        String selected = lstProgrammes.getSelectionModel().getSelectedItem();
        if (selected == null) { lblSettingsStatus.setText("Select a programme to remove."); return; }
        programmeRegistry.removeProgramme(selected);
        lblSettingsStatus.setText("Programme removed: " + selected);
    }
}
