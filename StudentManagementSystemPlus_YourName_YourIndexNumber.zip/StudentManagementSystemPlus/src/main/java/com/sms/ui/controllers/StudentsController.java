package com.sms.ui.controllers;

import com.sms.domain.Student;
import com.sms.domain.ValidationResult;
import com.sms.service.StudentService;
import com.sms.util.ProgrammeRegistry;
import com.sms.util.ServiceLocator;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Students screen controller. Handles CRUD, search, filter, and sort.
 */
public class StudentsController {

    @FXML private TableView<Student> tblStudents;
    @FXML private TableColumn<Student, String>  colId;
    @FXML private TableColumn<Student, String>  colName;
    @FXML private TableColumn<Student, String>  colProg;
    @FXML private TableColumn<Student, Integer> colLevel;
    @FXML private TableColumn<Student, Double>  colGpa;
    @FXML private TableColumn<Student, String>  colEmail;
    @FXML private TableColumn<Student, String>  colPhone;
    @FXML private TableColumn<Student, String>  colDate;
    @FXML private TableColumn<Student, String>  colStatus;

    @FXML private TextField txtSearch;
    @FXML private ComboBox<String>  cboProgramme;
    @FXML private ComboBox<String>  cboLevel;
    @FXML private ComboBox<String>  cboStatus;

    // Form fields
    @FXML private Label       lblFormTitle;
    @FXML private TextField   txtId;
    @FXML private TextField   txtName;
    @FXML private ComboBox<String> cboFormProgramme;
    @FXML private ComboBox<String> cboFormLevel;
    @FXML private TextField   txtGpa;
    @FXML private TextField   txtEmail;
    @FXML private TextField   txtPhone;
    @FXML private ComboBox<String> cboFormStatus;
    @FXML private Label       lblFormError;
    @FXML private Label       lblStatus;

    private final StudentService studentService = ServiceLocator.getInstance().getStudentService();
    private final ProgrammeRegistry programmeRegistry = ServiceLocator.getInstance().getProgrammeRegistry();

    private final ObservableList<Student> tableData = FXCollections.observableArrayList();
    private boolean editMode = false;

    @FXML
    public void initialize() {
        setupColumns();
        setupCombos();
        tblStudents.setItems(tableData);
        tblStudents.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> {
            if (n != null && !editMode) populateForm(n);
        });
        loadAll();
    }

    private void setupColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colProg.setCellValueFactory(new PropertyValueFactory<>("programme"));
        colLevel.setCellValueFactory(new PropertyValueFactory<>("level"));
        colGpa.setCellValueFactory(new PropertyValueFactory<>("gpa"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("dateAdded"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void setupCombos() {
        // Filter combos
        ObservableList<String> progOptions = FXCollections.observableArrayList("All");
        progOptions.addAll(programmeRegistry.getProgrammes());
        cboProgramme.setItems(progOptions);
        cboProgramme.setValue("All");

        cboLevel.setItems(FXCollections.observableArrayList("All", "100", "200", "300", "400", "500", "600", "700"));
        cboLevel.setValue("All");

        cboStatus.setItems(FXCollections.observableArrayList("All", "Active", "Inactive"));
        cboStatus.setValue("All");

        // Form combos
        cboFormProgramme.setItems(programmeRegistry.getProgrammes());
        cboFormLevel.setItems(FXCollections.observableArrayList("100", "200", "300", "400", "500", "600", "700"));
        cboFormStatus.setItems(FXCollections.observableArrayList("Active", "Inactive"));
        cboFormStatus.setValue("Active");
    }

    private void loadAll() {
        List<Student> students = studentService.getAllStudents();
        tableData.setAll(students);
        lblStatus.setText(students.size() + " student(s) loaded.");
    }

    @FXML public void refresh() { loadAll(); }

    @FXML public void search() {
        String q = txtSearch.getText().trim();
        if (q.isEmpty()) { loadAll(); return; }
        List<Student> results = studentService.searchStudents(q);
        tableData.setAll(results);
        lblStatus.setText(results.size() + " result(s) found.");
    }

    @FXML public void clearSearch() {
        txtSearch.clear();
        loadAll();
    }

    @FXML public void applyFilters() {
        String prog = cboProgramme.getValue();
        String levelStr = cboLevel.getValue();
        String status = cboStatus.getValue();
        Integer level = (levelStr == null || levelStr.equals("All")) ? null : Integer.parseInt(levelStr);
        List<Student> results = studentService.filterStudents(prog, level, status);
        tableData.setAll(results);
        lblStatus.setText(results.size() + " student(s) after filtering.");
    }

    @FXML public void resetFilters() {
        cboProgramme.setValue("All");
        cboLevel.setValue("All");
        cboStatus.setValue("All");
        loadAll();
    }

    @FXML public void sortByName() {
        List<Student> sorted = studentService.sortByName(tableData);
        tableData.setAll(sorted);
    }

    @FXML public void sortByGpa() {
        List<Student> sorted = studentService.sortByGpaDesc(tableData);
        tableData.setAll(sorted);
    }

    @FXML public void addStudent() {
        editMode = false;
        lblFormTitle.setText("Add Student");
        clearForm();
        txtId.setEditable(true);
    }

    @FXML public void editStudent() {
        Student selected = tblStudents.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a student to edit.");
            return;
        }
        editMode = true;
        lblFormTitle.setText("Edit Student");
        populateForm(selected);
        txtId.setEditable(false);
    }

    @FXML public void deleteStudent() {
        Student selected = tblStudents.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a student to delete.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Are you sure you want to delete student: " + selected.getFullName() + "?",
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm Delete");
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.YES) {
            studentService.deleteStudent(selected.getStudentId());
            loadAll();
            clearForm();
            lblStatus.setText("Student deleted.");
        }
    }

    @FXML public void saveStudent() {
        Student student = buildStudentFromForm();
        if (student == null) return;

        ValidationResult result;
        if (editMode) {
            result = studentService.updateStudent(student);
        } else {
            result = studentService.addStudent(student);
        }

        if (result.isValid()) {
            loadAll();
            clearForm();
            editMode = false;
            lblFormError.setText("");
            lblStatus.setText("Student saved successfully.");
        } else {
            lblFormError.setText(result.getErrorMessage());
        }
    }

    @FXML public void cancelForm() {
        clearForm();
        editMode = false;
        lblFormError.setText("");
    }

    private Student buildStudentFromForm() {
        Student s = new Student();
        s.setStudentId(txtId.getText().trim());
        s.setFullName(txtName.getText().trim());
        s.setProgramme(cboFormProgramme.getValue() != null ? cboFormProgramme.getValue() : "");
        try {
            s.setLevel(Integer.parseInt(cboFormLevel.getValue() != null ? cboFormLevel.getValue() : "0"));
        } catch (NumberFormatException e) {
            lblFormError.setText("Please select a valid level.");
            return null;
        }
        try {
            s.setGpa(Double.parseDouble(txtGpa.getText().trim()));
        } catch (NumberFormatException e) {
            lblFormError.setText("GPA must be a number (e.g. 3.50).");
            return null;
        }
        s.setEmail(txtEmail.getText().trim());
        s.setPhoneNumber(txtPhone.getText().trim());
        s.setDateAdded(LocalDate.now());
        s.setStatus(cboFormStatus.getValue() != null ? cboFormStatus.getValue() : "Active");
        return s;
    }

    private void populateForm(Student s) {
        txtId.setText(s.getStudentId());
        txtName.setText(s.getFullName());
        cboFormProgramme.setValue(s.getProgramme());
        cboFormLevel.setValue(String.valueOf(s.getLevel()));
        txtGpa.setText(String.valueOf(s.getGpa()));
        txtEmail.setText(s.getEmail());
        txtPhone.setText(s.getPhoneNumber());
        cboFormStatus.setValue(s.getStatus());
    }

    private void clearForm() {
        txtId.clear(); txtName.clear(); txtGpa.clear(); txtEmail.clear(); txtPhone.clear();
        cboFormProgramme.setValue(null);
        cboFormLevel.setValue(null);
        cboFormStatus.setValue("Active");
        lblFormError.setText("");
        txtId.setEditable(true);
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type, msg, ButtonType.OK);
        alert.setTitle(title);
        alert.showAndWait();
    }
}
