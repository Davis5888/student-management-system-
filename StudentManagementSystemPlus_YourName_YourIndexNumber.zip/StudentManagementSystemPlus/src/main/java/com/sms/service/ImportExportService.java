package com.sms.service;

import com.sms.domain.ImportResult;
import com.sms.domain.Student;
import com.sms.domain.ValidationResult;
import com.sms.repository.StudentRepository;
import com.sms.util.AppLogger;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * Handles CSV import and export operations.
 */
public class ImportExportService {

    private static final String DATA_DIR = "data";
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    private final StudentRepository repository;
    private final ValidationService validationService;

    public ImportExportService(StudentRepository repository, ValidationService validationService) {
        this.repository = repository;
        this.validationService = validationService;
    }

    /** Export all students to CSV. */
    public String exportAllStudents() throws IOException {
        ensureDataDir();
        String filename = DATA_DIR + File.separator + "students_export_" + LocalDateTime.now().format(TS) + ".csv";
        List<Student> students = repository.findAll();
        writeCsv(filename, students);
        AppLogger.info("Exported all students to: " + filename + " (" + students.size() + " records)");
        return filename;
    }

    /** Export top performers report. */
    public String exportTopPerformers(List<Student> students) throws IOException {
        ensureDataDir();
        String filename = DATA_DIR + File.separator + "top_performers_" + LocalDateTime.now().format(TS) + ".csv";
        writeCsv(filename, students);
        AppLogger.info("Exported top performers to: " + filename);
        return filename;
    }

    /** Export at-risk report. */
    public String exportAtRisk(List<Student> students) throws IOException {
        ensureDataDir();
        String filename = DATA_DIR + File.separator + "at_risk_" + LocalDateTime.now().format(TS) + ".csv";
        writeCsv(filename, students);
        AppLogger.info("Exported at-risk students to: " + filename);
        return filename;
    }

    /** Import students from CSV. */
    public ImportResult importFromCsv(String filePath) throws IOException {
        ImportResult result = new ImportResult();
        ensureDataDir();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String header = reader.readLine(); // skip header
            if (header == null) return result;

            String line;
            int row = 2;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) { row++; continue; }
                try {
                    Student student = parseCsvLine(line);
                    if (repository.existsById(student.getStudentId())) {
                        result.addError(row, "Duplicate Student ID: " + student.getStudentId());
                    } else {
                        ValidationResult vr = validationService.validateForImport(student);
                        if (!vr.isValid()) {
                            result.addError(row, vr.getErrorMessage());
                        } else {
                            repository.add(student);
                            result.addSuccess();
                        }
                    }
                } catch (Exception e) {
                    result.addError(row, "Parse error: " + e.getMessage());
                }
                row++;
            }
        }

        // Save import error report
        if (result.getErrorCount() > 0) {
            String errFile = DATA_DIR + File.separator + "import_errors_" + LocalDateTime.now().format(TS) + ".csv";
            try (PrintWriter pw = new PrintWriter(new FileWriter(errFile))) {
                pw.println("Row,Error");
                for (String msg : result.getErrorMessages()) {
                    pw.println("\"" + msg.replace("\"", "\"\"") + "\"");
                }
            }
            AppLogger.info("Import error report saved: " + errFile);
        }

        AppLogger.info("Import complete. Success=" + result.getSuccessCount() + " Errors=" + result.getErrorCount());
        return result;
    }

    private void writeCsv(String filename, List<Student> students) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            pw.println("StudentID,FullName,Programme,Level,GPA,Email,PhoneNumber,DateAdded,Status");
            for (Student s : students) {
                pw.printf("\"%s\",\"%s\",\"%s\",%d,%.2f,\"%s\",\"%s\",\"%s\",\"%s\"%n",
                        s.getStudentId(), s.getFullName(), s.getProgramme(),
                        s.getLevel(), s.getGpa(), s.getEmail(),
                        s.getPhoneNumber(), s.getDateAdded(), s.getStatus());
            }
        }
    }

    private Student parseCsvLine(String line) {
        // Simple CSV parsing (handles quoted fields)
        String[] parts = splitCsv(line);
        if (parts.length < 8) throw new IllegalArgumentException("Expected at least 8 columns");

        Student s = new Student();
        s.setStudentId(clean(parts[0]));
        s.setFullName(clean(parts[1]));
        s.setProgramme(clean(parts[2]));
        s.setLevel(Integer.parseInt(clean(parts[3])));
        s.setGpa(Double.parseDouble(clean(parts[4])));
        s.setEmail(clean(parts[5]));
        s.setPhoneNumber(clean(parts[6]));
        s.setDateAdded(LocalDate.parse(clean(parts[7])));
        s.setStatus(parts.length > 8 ? clean(parts[8]) : "Active");
        return s;
    }

    private String clean(String s) {
        return s.trim().replaceAll("^\"|\"$", "");
    }

    private String[] splitCsv(String line) {
        return line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
    }

    private void ensureDataDir() {
        File dir = new File(DATA_DIR);
        if (!dir.exists()) dir.mkdirs();
    }
}
