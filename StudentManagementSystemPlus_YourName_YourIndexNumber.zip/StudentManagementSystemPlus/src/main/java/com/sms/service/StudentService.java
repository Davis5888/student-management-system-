package com.sms.service;

import com.sms.domain.Student;
import com.sms.domain.ValidationResult;
import com.sms.repository.StudentRepository;
import com.sms.util.AppLogger;

import java.util.Comparator;
import java.util.List;

/**
 * Business logic for student management.
 */
public class StudentService {

    private final StudentRepository repository;
    private final ValidationService validationService;

    public StudentService(StudentRepository repository, ValidationService validationService) {
        this.repository = repository;
        this.validationService = validationService;
    }

    public ValidationResult addStudent(Student student) {
        ValidationResult result = validationService.validate(student);
        if (!result.isValid()) return result;

        if (repository.existsById(student.getStudentId())) {
            result.addError("Student ID already exists: " + student.getStudentId());
            return result;
        }

        repository.add(student);
        return result;
    }

    public ValidationResult updateStudent(Student student) {
        ValidationResult result = validationService.validate(student);
        if (!result.isValid()) return result;

        if (!repository.existsById(student.getStudentId())) {
            result.addError("Student not found: " + student.getStudentId());
            return result;
        }

        repository.update(student);
        return result;
    }

    public void deleteStudent(String studentId) {
        repository.delete(studentId);
        AppLogger.info("Student deleted via service: ID=" + studentId);
    }

    public List<Student> getAllStudents() {
        return repository.findAll();
    }

    public List<Student> searchStudents(String query) {
        return repository.findByName(query);
    }

    public List<Student> filterStudents(String programme, Integer level, String status) {
        return repository.findByFilters(programme, level, status);
    }

    public List<Student> sortByGpaDesc(List<Student> students) {
        students.sort(Comparator.comparingDouble(Student::getGpa).reversed());
        return students;
    }

    public List<Student> sortByName(List<Student> students) {
        students.sort(Comparator.comparing(Student::getFullName));
        return students;
    }

    public int getTotalCount() { return repository.count(); }
    public int getActiveCount() { return repository.countByStatus("Active"); }
    public int getInactiveCount() { return repository.countByStatus("Inactive"); }
    public double getAverageGpa() { return repository.averageGpa(); }

    public java.util.Optional<Student> findById(String id) {
        return repository.findById(id);
    }
}
