package com.sms.service;

import com.sms.domain.Student;
import com.sms.repository.StudentRepository;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Generates reports and analytics.
 */
public class ReportService {

    private final StudentRepository repository;

    public ReportService(StudentRepository repository) {
        this.repository = repository;
    }

    /** Top 10 performers by GPA, with optional programme and level filters. */
    public List<Student> getTopPerformers(int topN, String programme, Integer level) {
        List<Student> all = repository.findAll();
        return all.stream()
                .filter(s -> (programme == null || programme.isBlank() || programme.equals("All") || s.getProgramme().equalsIgnoreCase(programme)))
                .filter(s -> (level == null || s.getLevel() == level))
                .sorted(Comparator.comparingDouble(Student::getGpa).reversed())
                .limit(topN)
                .collect(Collectors.toList());
    }

    /** Students with GPA below the threshold. */
    public List<Student> getAtRiskStudents(double threshold) {
        return repository.findAll().stream()
                .filter(s -> s.getGpa() < threshold)
                .sorted(Comparator.comparingDouble(Student::getGpa))
                .collect(Collectors.toList());
    }

    /** GPA distribution: count of students in bands 0-1, 1-2, 2-3, 3-4. */
    public Map<String, Long> getGpaDistribution() {
        List<Student> all = repository.findAll();
        Map<String, Long> dist = new LinkedHashMap<>();
        dist.put("0.0 - 1.0", all.stream().filter(s -> s.getGpa() < 1.0).count());
        dist.put("1.0 - 2.0", all.stream().filter(s -> s.getGpa() >= 1.0 && s.getGpa() < 2.0).count());
        dist.put("2.0 - 3.0", all.stream().filter(s -> s.getGpa() >= 2.0 && s.getGpa() < 3.0).count());
        dist.put("3.0 - 4.0", all.stream().filter(s -> s.getGpa() >= 3.0 && s.getGpa() <= 4.0).count());
        return dist;
    }

    /** Programme summary: total students and average GPA per programme. */
    public List<Map<String, Object>> getProgrammeSummary() {
        List<Student> all = repository.findAll();
        Map<String, List<Student>> byProgramme = all.stream()
                .collect(Collectors.groupingBy(Student::getProgramme));

        List<Map<String, Object>> result = new ArrayList<>();
        for (Map.Entry<String, List<Student>> entry : byProgramme.entrySet()) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("Programme", entry.getKey());
            row.put("Total", entry.getValue().size());
            double avg = entry.getValue().stream().mapToDouble(Student::getGpa).average().orElse(0.0);
            row.put("Average GPA", String.format("%.2f", avg));
            result.add(row);
        }
        result.sort(Comparator.comparing(r -> r.get("Programme").toString()));
        return result;
    }
}
