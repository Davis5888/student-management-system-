package com.sms.service;

import com.sms.domain.Student;
import com.sms.domain.ValidationResult;

import java.util.Set;

/**
 * Validates student input fields.
 */
public class ValidationService {

    private static final Set<Integer> VALID_LEVELS = Set.of(100, 200, 300, 400, 500, 600, 700);

    public ValidationResult validate(Student student) {
        ValidationResult result = new ValidationResult();

        // Student ID
        if (student.getStudentId() == null || student.getStudentId().isBlank()) {
            result.addError("Student ID is required.");
        } else {
            String id = student.getStudentId().trim();
            if (id.length() < 4 || id.length() > 20) {
                result.addError("Student ID must be 4 to 20 characters.");
            } else if (!id.matches("[A-Za-z0-9]+")) {
                result.addError("Student ID must contain only letters and digits.");
            }
        }

        // Full name
        if (student.getFullName() == null || student.getFullName().isBlank()) {
            result.addError("Full name is required.");
        } else {
            String name = student.getFullName().trim();
            if (name.length() < 2 || name.length() > 60) {
                result.addError("Full name must be 2 to 60 characters.");
            } else if (name.matches(".*\\d.*")) {
                result.addError("Full name must not contain digits.");
            }
        }

        // Programme
        if (student.getProgramme() == null || student.getProgramme().isBlank()) {
            result.addError("Programme is required.");
        }

        // Level
        if (!VALID_LEVELS.contains(student.getLevel())) {
            result.addError("Level must be one of: 100, 200, 300, 400, 500, 600, 700.");
        }

        // GPA
        if (student.getGpa() < 0.0 || student.getGpa() > 4.0) {
            result.addError("GPA must be between 0.0 and 4.0.");
        }

        // Email
        if (student.getEmail() == null || student.getEmail().isBlank()) {
            result.addError("Email is required.");
        } else {
            String email = student.getEmail().trim();
            if (!email.contains("@") || !email.contains(".")) {
                result.addError("Email must contain an @ sign and a dot.");
            }
        }

        // Phone number
        if (student.getPhoneNumber() == null || student.getPhoneNumber().isBlank()) {
            result.addError("Phone number is required.");
        } else {
            String phone = student.getPhoneNumber().trim();
            if (!phone.matches("\\d{10,15}")) {
                result.addError("Phone number must be 10 to 15 digits (digits only).");
            }
        }

        return result;
    }

    public ValidationResult validateForImport(Student student) {
        return validate(student);
    }
}
