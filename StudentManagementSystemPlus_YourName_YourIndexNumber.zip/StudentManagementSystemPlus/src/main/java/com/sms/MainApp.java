package com.sms;

import com.sms.util.AppLogger;
import com.sms.util.DatabaseManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Entry point for the Student Management System Plus.
 */
public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        AppLogger.info("Application starting.");
        DatabaseManager.initializeDatabase();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/sms/ui/MainView.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root, 1100, 720);
        scene.getStylesheets().add(getClass().getResource("/com/sms/ui/style.css").toExternalForm());

        primaryStage.setTitle("Student Management System Plus v1.0");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(900);
        primaryStage.setMinHeight(600);
        primaryStage.show();

        primaryStage.setOnCloseRequest(e -> {
            AppLogger.info("Application closing.");
            DatabaseManager.closeConnection();
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
