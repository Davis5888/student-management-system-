package com.sms.service;

import com.sms.domain.Student;
import com.sms.domain.ValidationResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for StudentService.
 */
class StudentServiceTest {

    private StudentService studentService;
    private ReportServiceTest.StubStudentRepository stubRepo;

    @BeforeEach
    void setUp() {
        stubRepo = new ReportServiceTest.StubStudentRepository();
        studentService = new StudentService(stubRepo, new ValidationService());
    }

    private Student validStudent(String id) {
        Student s = new Student();
        s.setStudentId(id);
        s.setFullName("Test Student");
        s.setProgramme("Computer Science");
        s.setLevel(200);
        s.setGpa(3.0);
        s.setEmail("test@example.com");
        s.setPhoneNumber("0200000000");
        s.setDateAdded(LocalDate.now());
        s.setStatus("Active");
        return s;
    }

    @Test
    void testAddValidStudent() {
        ValidationResult result = studentService.addStudent(validStudent("NEW001"));
        assertTrue(result.isValid());
        assertEquals(1, studentService.getTotalCount());
    }

    @Test
    void testAddDuplicateStudentFails() {
        studentService.addStudent(validStudent("DUP001"));
        ValidationResult result = studentService.addStudent(validStudent("DUP001"));
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("already exists"));
    }

    @Test
    void testDeleteStudent() {
        studentService.addStudent(validStudent("DEL001"));
        assertEquals(1, studentService.getTotalCount());
        studentService.deleteStudent("DEL001");
        assertEquals(0, studentService.getTotalCount());
    }

    @Test
    void testUpdateStudent() {
        studentService.addStudent(validStudent("UPD001"));
        Student updated = validStudent("UPD001");
        updated.setFullName("Updated Name");
        ValidationResult result = studentService.updateStudent(updated);
        assertTrue(result.isValid());
    }

    @Test
    void testSortByGpaDesc() {
        List<Student> students = new ArrayList<>();
        Student a = validStudent("A1"); a.setGpa(2.0); students.add(a);
        Student b = validStudent("B1"); b.setGpa(3.5); students.add(b);
        Student c = validStudent("C1"); c.setGpa(1.0); students.add(c);
        List<Student> sorted = studentService.sortByGpaDesc(students);
        assertEquals(3.5, sorted.get(0).getGpa(), 0.001);
        assertEquals(1.0, sorted.get(2).getGpa(), 0.001);
    }

    @Test
    void testSortByName() {
        List<Student> students = new ArrayList<>();
        Student a = validStudent("A1"); a.setFullName("Zara"); students.add(a);
        Student b = validStudent("B1"); b.setFullName("Alex"); students.add(b);
        List<Student> sorted = studentService.sortByName(students);
        assertEquals("Alex", sorted.get(0).getFullName());
    }
}
