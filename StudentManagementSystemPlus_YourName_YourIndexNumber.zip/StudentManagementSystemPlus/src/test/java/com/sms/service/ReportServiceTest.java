package com.sms.service;

import com.sms.domain.Student;
import com.sms.repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ReportService using an in-memory stub repository.
 */
class ReportServiceTest {

    private ReportService reportService;
    private StubStudentRepository stubRepo;

    @BeforeEach
    void setUp() {
        stubRepo = new StubStudentRepository();
        populateSampleData();
        reportService = new ReportService(stubRepo);
    }

    private void populateSampleData() {
        stubRepo.add(makeStudent("S001", "Alice Smith",    "Computer Science", 300, 3.8));
        stubRepo.add(makeStudent("S002", "Bob Jones",      "Computer Science", 200, 1.5));
        stubRepo.add(makeStudent("S003", "Carol Adams",    "Mathematics",      400, 3.2));
        stubRepo.add(makeStudent("S004", "Dan Brown",      "Mathematics",      300, 0.9));
        stubRepo.add(makeStudent("S005", "Eve White",      "IT",               100, 4.0));
        stubRepo.add(makeStudent("S006", "Frank Green",    "IT",               200, 2.5));
        stubRepo.add(makeStudent("S007", "Grace Lee",      "Computer Science", 500, 3.9));
        stubRepo.add(makeStudent("S008", "Henry Ford",     "Mathematics",      200, 1.8));
        stubRepo.add(makeStudent("S009", "Ivy Chen",       "IT",               400, 2.9));
        stubRepo.add(makeStudent("S010", "Jack Black",     "Computer Science", 100, 1.1));
        stubRepo.add(makeStudent("S011", "Karen Davis",    "IT",               300, 3.5));
        stubRepo.add(makeStudent("S012", "Leo Martin",     "Mathematics",      400, 0.5));
    }

    private Student makeStudent(String id, String name, String prog, int level, double gpa) {
        Student s = new Student();
        s.setStudentId(id);
        s.setFullName(name);
        s.setProgramme(prog);
        s.setLevel(level);
        s.setGpa(gpa);
        s.setEmail(id.toLowerCase() + "@test.com");
        s.setPhoneNumber("0200000000");
        s.setDateAdded(LocalDate.now());
        s.setStatus("Active");
        return s;
    }

    // ── Top Performers ───────────────────────────────────
    @Test
    void testTopPerformersCount() {
        List<Student> top = reportService.getTopPerformers(5, null, null);
        assertEquals(5, top.size());
    }

    @Test
    void testTopPerformersAreOrdered() {
        List<Student> top = reportService.getTopPerformers(12, null, null);
        for (int i = 0; i < top.size() - 1; i++) {
            assertTrue(top.get(i).getGpa() >= top.get(i+1).getGpa(), "Should be sorted desc by GPA");
        }
    }

    @Test
    void testTopPerformersByProgramme() {
        List<Student> top = reportService.getTopPerformers(10, "Computer Science", null);
        assertTrue(top.stream().allMatch(s -> s.getProgramme().equals("Computer Science")));
    }

    @Test
    void testTopPerformersByLevel() {
        List<Student> top = reportService.getTopPerformers(10, null, 300);
        assertTrue(top.stream().allMatch(s -> s.getLevel() == 300));
    }

    // ── At Risk ──────────────────────────────────────────
    @Test
    void testAtRiskDefaultThreshold() {
        List<Student> atRisk = reportService.getAtRiskStudents(2.0);
        assertTrue(atRisk.stream().allMatch(s -> s.getGpa() < 2.0));
    }

    @Test
    void testAtRiskCount() {
        // S002=1.5, S004=0.9, S008=1.8, S010=1.1, S012=0.5 → 5 below 2.0
        List<Student> atRisk = reportService.getAtRiskStudents(2.0);
        assertEquals(5, atRisk.size());
    }

    @Test
    void testAtRiskSortedAscendingByGpa() {
        List<Student> atRisk = reportService.getAtRiskStudents(2.0);
        for (int i = 0; i < atRisk.size() - 1; i++) {
            assertTrue(atRisk.get(i).getGpa() <= atRisk.get(i+1).getGpa());
        }
    }

    // ── GPA Distribution ─────────────────────────────────
    @Test
    void testGpaDistributionHasFourBands() {
        Map<String, Long> dist = reportService.getGpaDistribution();
        assertEquals(4, dist.size());
    }

    @Test
    void testGpaDistributionTotalsMatchAllStudents() {
        Map<String, Long> dist = reportService.getGpaDistribution();
        long total = dist.values().stream().mapToLong(Long::longValue).sum();
        assertEquals(12, total, "All 12 students should be distributed");
    }

    @Test
    void testGpaDistributionBand3to4() {
        // S001=3.8, S003=3.2, S005=4.0, S007=3.9, S011=3.5 → 5 in 3.0-4.0
        Map<String, Long> dist = reportService.getGpaDistribution();
        assertEquals(5L, dist.get("3.0 - 4.0"));
    }

    // ── Programme Summary ────────────────────────────────
    @Test
    void testProgrammeSummaryHasAllProgrammes() {
        List<Map<String, Object>> summary = reportService.getProgrammeSummary();
        List<String> progs = summary.stream().map(r -> r.get("Programme").toString()).toList();
        assertTrue(progs.containsAll(List.of("Computer Science", "Mathematics", "IT")));
    }

    @Test
    void testProgrammeSummaryTotals() {
        List<Map<String, Object>> summary = reportService.getProgrammeSummary();
        // CS has 4 students
        Map<String, Object> cs = summary.stream().filter(r -> r.get("Programme").equals("Computer Science")).findFirst().orElseThrow();
        assertEquals(4, (int) cs.get("Total"));
    }

    // ── Stub repository ──────────────────────────────────
    static class StubStudentRepository implements StudentRepository {
        private final List<Student> store = new ArrayList<>();

        @Override public void add(Student s) { store.add(s); }
        @Override public void update(Student s) {}
        @Override public void delete(String id) { store.removeIf(s -> s.getStudentId().equals(id)); }
        @Override public Optional<Student> findById(String id) { return store.stream().filter(s -> s.getStudentId().equals(id)).findFirst(); }
        @Override public List<Student> findAll() { return new ArrayList<>(store); }
        @Override public List<Student> findByName(String name) { return store.stream().filter(s -> s.getFullName().contains(name)).toList(); }
        @Override public List<Student> findByFilters(String prog, Integer level, String status) { return findAll(); }
        @Override public boolean existsById(String id) { return store.stream().anyMatch(s -> s.getStudentId().equals(id)); }
        @Override public int count() { return store.size(); }
        @Override public int countByStatus(String status) { return (int) store.stream().filter(s -> s.getStatus().equals(status)).count(); }
        @Override public double averageGpa() { return store.stream().mapToDouble(Student::getGpa).average().orElse(0); }
    }
}
