package com.sms.service;

import com.sms.domain.Student;
import com.sms.domain.ValidationResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ValidationService.
 */
class ValidationServiceTest {

    private ValidationService validationService;

    @BeforeEach
    void setUp() {
        validationService = new ValidationService();
    }

    private Student validStudent() {
        Student s = new Student();
        s.setStudentId("STU1234");
        s.setFullName("John Doe");
        s.setProgramme("Computer Science");
        s.setLevel(200);
        s.setGpa(3.5);
        s.setEmail("john.doe@example.com");
        s.setPhoneNumber("0200001234");
        s.setDateAdded(LocalDate.now());
        s.setStatus("Active");
        return s;
    }

    // ── Student ID tests ────────────────────────────────
    @Test
    void testValidStudentPassesValidation() {
        ValidationResult result = validationService.validate(validStudent());
        assertTrue(result.isValid(), "Valid student should pass validation: " + result.getErrorMessage());
    }

    @Test
    void testStudentIdTooShort() {
        Student s = validStudent();
        s.setStudentId("AB");
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("4 to 20"));
    }

    @Test
    void testStudentIdWithSpecialChars() {
        Student s = validStudent();
        s.setStudentId("STU@123");
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("letters and digits"));
    }

    @Test
    void testStudentIdNull() {
        Student s = validStudent();
        s.setStudentId(null);
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("required"));
    }

    // ── Full name tests ──────────────────────────────────
    @Test
    void testFullNameWithDigits() {
        Student s = validStudent();
        s.setFullName("John2 Doe");
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("digits"));
    }

    @Test
    void testFullNameTooShort() {
        Student s = validStudent();
        s.setFullName("A");
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("2 to 60"));
    }

    // ── Level tests ──────────────────────────────────────
    @Test
    void testInvalidLevel() {
        Student s = validStudent();
        s.setLevel(150);
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("Level"));
    }

    @Test
    void testAllValidLevels() {
        int[] levels = {100, 200, 300, 400, 500, 600, 700};
        for (int level : levels) {
            Student s = validStudent();
            s.setLevel(level);
            ValidationResult result = validationService.validate(s);
            assertTrue(result.isValid(), "Level " + level + " should be valid");
        }
    }

    // ── GPA tests ─────────────────────────────────────────
    @Test
    void testGpaBelowZero() {
        Student s = validStudent();
        s.setGpa(-0.1);
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("GPA"));
    }

    @Test
    void testGpaAbove4() {
        Student s = validStudent();
        s.setGpa(4.1);
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("GPA"));
    }

    // ── Email tests ──────────────────────────────────────
    @Test
    void testEmailWithoutAtSign() {
        Student s = validStudent();
        s.setEmail("johndoe.com");
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("@"));
    }

    // ── Phone tests ──────────────────────────────────────
    @Test
    void testPhoneTooShort() {
        Student s = validStudent();
        s.setPhoneNumber("123456789");
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("10 to 15"));
    }

    @Test
    void testPhoneWithLetters() {
        Student s = validStudent();
        s.setPhoneNumber("02000abc56");
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrorMessage().contains("digits"));
    }

    // ── Multiple errors ──────────────────────────────────
    @Test
    void testMultipleValidationErrors() {
        Student s = new Student();
        s.setStudentId("");
        s.setFullName("");
        s.setProgramme("");
        s.setLevel(999);
        s.setGpa(5.0);
        s.setEmail("bad");
        s.setPhoneNumber("123");
        ValidationResult result = validationService.validate(s);
        assertFalse(result.isValid());
        assertTrue(result.getErrors().size() >= 5);
    }
}
